package com.example.pfe2023.helpers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pfe2023.R;
import com.example.pfe2023.models.Destination;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    Context context;
    private ArrayList<Destination> items;

    public MyAdapter(ArrayList<Destination> items, Context context) {
        this.items = items;
    }
    public void filterList(ArrayList<Destination> filterlist) {
        // below line is to add our filtered
        // list in our course array list.
        items = filterlist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // below line is to inflate our layout.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
        holder.name.setText(items.get(position).getName());
        Picasso.get().load(items.get(position).getImg()).into(holder.imageView);
        holder.gouvernate.setText(items.get(position).getGouvernate());
        holder.wait.setText(items.get(position).getWait() + "");
        holder.budget.setText(items.get(position).getBudget() + "");
    }

    @Override
    public int getItemCount() {
        return items.size() ;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
          public AppCompatImageView imageView ;
        public AppCompatTextView name;
         public AppCompatTextView gouvernate;


          public AppCompatTextView wait;
         public AppCompatTextView budget;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

             imageView = itemView.findViewById(R.id.listImg);
            name = itemView.findViewById(R.id.name);
             gouvernate = itemView.findViewById(R.id.Gouvernate);
             wait = itemView.findViewById(R.id.Wait);
             budget = itemView.findViewById(R.id.Budget);
        }
    }
}
