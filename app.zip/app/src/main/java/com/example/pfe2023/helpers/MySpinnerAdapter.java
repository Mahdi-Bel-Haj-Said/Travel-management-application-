package com.example.pfe2023.helpers;

import static androidx.core.content.ContextCompat.getColor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import androidx.appcompat.widget.AppCompatTextView;

import com.example.pfe2023.R;
import com.example.pfe2023.models.Destination;

import java.util.ArrayList;

public class MySpinnerAdapter extends BaseAdapter {

    Context context;
    ArrayList<Destination> mData;
    LayoutInflater inflter;

    public MySpinnerAdapter(Context applicationContext, ArrayList<Destination> mData) {
        this.context = applicationContext;
        this.mData = mData;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.spinner_row_item, null);
        AppCompatTextView names = (AppCompatTextView) view.findViewById(R.id.tv_spinner_row_text);
        names.setText(mData.get(i).getName());

        return view;
    }
}