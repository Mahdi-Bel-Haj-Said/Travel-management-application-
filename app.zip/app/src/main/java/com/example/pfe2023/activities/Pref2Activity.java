package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.ALL_ATTRACTIONS;
import static com.example.pfe2023.helpers.ConstantConfig.ALL_DESTINATIONS;
import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.ConstantConfig.SELECTED_ATTRACTIONS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.pfe2023.R;
import com.example.pfe2023.helpers.AttractionAdapter;
import com.example.pfe2023.models.Attraction;
import com.example.pfe2023.models.Destination;
import com.example.pfe2023.models.UserAtt;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;

public class Pref2Activity extends AppCompatActivity {

RecyclerView recyclerView ;
private ArrayList<UserAtt> attractions = new ArrayList<>();
private AttractionAdapter adapter ;

    AppCompatButton btn ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pref2);

        recyclerView = findViewById(R.id.attractionRecycler);
        btn = findViewById(R.id.submit);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));

        adapter = new AttractionAdapter(this , ALL_ATTRACTIONS );
        recyclerView.setAdapter(adapter);
        adapter.setAttractions(ALL_ATTRACTIONS);

//        CreateListOfData();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(adapter.getSelected().size()>0)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i = 0 ; i < adapter.getSelected().size();i++)
                    {
                        stringBuilder.append(adapter.getSelected().get(i).getAttName());
                        stringBuilder.append("\n");

                    }
                    ShowToast(stringBuilder.toString().trim());
                    SELECTED_ATTRACTIONS = adapter.getSelected();
                    CUR_USER.setUserAtt(SELECTED_ATTRACTIONS);
                    Intent i = new Intent(getApplicationContext(), GeneratedDestinationsActivity.class);
                    startActivity(i);
                    finish();
                }else
                    ShowToast("No selection");
            }
        });


    }

//    private void CreateListOfData() {
//
//        attractions = new ArrayList<>();
////        for (int i=0 ; i< 20 ; i++){
////            Attraction attraction = new Attraction();
////            attraction.setAttraction("Attraction" + (i+1));
////            attractions.add(attraction);
////        }
////
////
////        attractions.add(new Attraction("Historical sites"));
////        attractions.add(new Attraction("Cultural sites"));
////        attractions.add(new Attraction("Artistic galleries"));
////        attractions.add(new Attraction("Traditional food"));
////
////        attractions.add(new Attraction("Theaters, Concerts and Cinemas"));
////        attractions.add(new Attraction("Markets"));
////        attractions.add(new Attraction("Sports Arenas and Stadiums"));
////        attractions.add(new Attraction("Beaches and Coastal Areas"));
////        attractions.add(new Attraction("Sahara"));
////        attractions.add(new Attraction("Mountains"));
//
//        attractions = CUR_USER.getUserAtt();
//
//    }
    private void ShowToast(String msg){
        Toast.makeText(this ,msg , Toast.LENGTH_SHORT).show();
    }
}