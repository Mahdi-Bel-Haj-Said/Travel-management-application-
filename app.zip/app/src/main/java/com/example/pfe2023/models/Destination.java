package com.example.pfe2023.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Destination {
    @SerializedName("place_id")
    @Expose
    private Integer id;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("gouvernate")
    @Expose
    private String Gouvernate;

    @SerializedName("longitude")
    @Expose
    private String Longitude;

    @SerializedName("latitude")
    @Expose
    private String Latitude;

    @SerializedName("waittime")
    @Expose
    private Integer wait;

    @SerializedName("budget")
    @Expose
    private Double budget;

    @SerializedName("image")
    @Expose
    private String Img;
    @SerializedName("attractions")
    @Expose
    List<Attraction> attractions;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGouvernate() {
        return Gouvernate;
    }

    public void setGouvernate(String gouvernate) {
        Gouvernate = gouvernate;
    }

    public String getLongitude() {
        return Longitude;
    }

    public void setLongitude(String longitude) {
        Longitude = longitude;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }

    public Integer getWait() {
        return wait;
    }

    public void setWait(Integer wait) {
        this.wait = wait;
    }

    public Double getBudget() {
        return budget;
    }

    public void setBudget(Double budget) {
        this.budget = budget;
    }

    public String getImg() {
        return Img;
    }

    public void setImg(String img) {
        Img = img;
    }

    public List<Attraction> getAttractions() {
        return attractions;
    }

    public void setAttractions(List<Attraction> attractions) {
        this.attractions = attractions;
    }

    public Destination(String name) {
        this.name = name;
    }
}
