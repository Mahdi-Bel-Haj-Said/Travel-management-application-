package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.Utils.showSnackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

import com.example.pfe2023.R;
import com.example.pfe2023.models.LoginResponse;
import com.example.pfe2023.models.UserLogin;
import com.example.pfe2023.models.UserPref;
import com.example.pfe2023.retrofit.RetrofitClient;
import com.example.pfe2023.retrofit.RetrofitInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Pref1Activity extends AppCompatActivity {

    AppCompatSeekBar seekBar1 , seekBar2 ;
    AppCompatTextView budget , wait ;
    AppCompatButton nextBtn;

    int waitVal;
    double budgetVal ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pref1);

        seekBar1 = findViewById(R.id.seekbar1);
        seekBar2 = findViewById(R.id.seekbar2);
        wait = findViewById(R.id.valeurWait);
        budget = findViewById(R.id.valeurBudget);
        nextBtn = findViewById(R.id.Next);
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                wait.setText(String.valueOf(progress));
                waitVal = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                budget.setText(String.valueOf(progress));
                budgetVal = progress ;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                        addPref();
                Intent i = new Intent(getApplicationContext(), Pref2Activity.class);
                startActivity(i);
            }
        });

    }

    /*************************************(  POST  )****************************************/
    public void addPref() {
        String URL = "api/User/UpdateUser";
        final String content_type = "application/json";
        UserPref _UserPref = new UserPref();
        _UserPref.setWait(waitVal);
        _UserPref.setBudget(budgetVal);

        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<LoginResponse> prefCall = service.addUserPrefQuery(URL, content_type, _UserPref);

        nextBtn.setEnabled(false);

        prefCall.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.raw().code() == 200) {
                    LoginResponse _Data = response.body();
                    if (_Data.getSuccess()){
                        CUR_USER.setUserPref(_Data.getUser().getUserPref());
                    } else {
                        showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());
                    }
                    showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());

                } else {
                    showSnackbar(findViewById(android.R.id.content), response.message());
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), "error_message_server_down");

            }
        });

    }





}