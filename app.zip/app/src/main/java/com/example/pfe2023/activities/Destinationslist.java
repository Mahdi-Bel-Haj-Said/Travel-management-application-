package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.ALL_DESTINATIONS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.example.pfe2023.R;
import com.example.pfe2023.helpers.MyAdapter;
import com.example.pfe2023.models.Destination;

import java.util.ArrayList;

public class Destinationslist extends AppCompatActivity {
    private SearchView  searchview;
    private RecyclerView RecyclerView;


    private MyAdapter myAdapter;
    private ArrayList<Destination> Destination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);


        RecyclerView = findViewById(R.id.recyclerView);
        buildRecyclerView();

        searchview = findViewById(R.id.search);
        searchview.clearFocus();
        searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });
    }

    private void filter(String Text) {
        ArrayList<Destination> filtered = new ArrayList<Destination>();

        for (Destination item : Destination) {
            if (item.getName().toLowerCase().contains(Text.toLowerCase())){
                filtered.add(item);
            }
        }
        if (filtered.isEmpty()){
            Toast.makeText(this,"No data found " , Toast.LENGTH_SHORT).show();
            myAdapter.filterList(filtered);
        }
        else {
            myAdapter.filterList(filtered);
        }
    }

    private void buildRecyclerView() {
        // below line we are creating a new array list
        Destination = ALL_DESTINATIONS;

        myAdapter = new MyAdapter(Destination, Destinationslist.this);
        // adding layout manager to our recycler view.
        LinearLayoutManager manager = new LinearLayoutManager(this);
        RecyclerView.setHasFixedSize(true);

        // setting layout manager
        // to our recycler view.
        RecyclerView.setLayoutManager(manager);

        // setting adapter to
        // our recycler view.
        RecyclerView.setAdapter(myAdapter);
    }
}