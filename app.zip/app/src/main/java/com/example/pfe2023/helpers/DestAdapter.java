package com.example.pfe2023.helpers;

import static com.example.pfe2023.helpers.Utils.showSnackbar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.widget.TextViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pfe2023.R;
import com.example.pfe2023.models.Attraction;
import com.example.pfe2023.models.Destination;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class DestAdapter  extends RecyclerView.Adapter<DemoVH> {

    ArrayList<Destination> items;

    public DestAdapter(ArrayList<Destination> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public DemoVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_dest, parent , false);
        return new DemoVH(view).linkAdapter(this);
    }

    @Override
    public void onBindViewHolder(@NonNull DemoVH holder, int position) {
        holder.textView.setText(items.get(position).getName());
        holder.destnumber.setText("");
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}

class DemoVH extends RecyclerView.ViewHolder{

    AppCompatTextView textView,destnumber;

    private DestAdapter adapter ;

    public DemoVH(@NonNull View itemView) {
        super(itemView);
        destnumber = itemView.findViewById(R.id.destnumber);
        textView = itemView.findViewById(R.id.Destinationname);
        itemView.findViewById(R.id.delete).setOnClickListener(view -> {
            adapter.items.remove(getAdapterPosition());
            adapter.notifyItemRemoved(getAdapterPosition());
        });
    }
    public DemoVH linkAdapter(DestAdapter adapter){
        this.adapter = adapter;
        return this;
    }
}
