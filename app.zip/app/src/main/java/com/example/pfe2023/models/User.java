package com.example.pfe2023.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class User {


    @SerializedName("id")
    @Expose
    private Integer userId;

    @SerializedName("firstName")
    @Expose
    private String FirstName;

    @SerializedName("lastName")
    @Expose
    private String LastName;

    @SerializedName("login")
    @Expose
    private String Login;

    @SerializedName("password")
    @Expose
    private String Password;

    @SerializedName("email")
    @Expose
    private String Email;

    @SerializedName("phone")
    @Expose
    private String Phone;

    @SerializedName("isActive")
    @Expose
    private boolean isActive;

    @SerializedName("userRole")
    @Expose
    private UserRole UserRole;

    @SerializedName("userPref")
    @Expose
    private UserPref UserPref;

    @SerializedName("userAtt")
    @Expose
    private ArrayList<UserAtt>  UserAtt;

    public ArrayList<UserAtt> getUserAtt() {
        return UserAtt;
    }

    public void setUserAtt(ArrayList<UserAtt> userAtt) {
        UserAtt = userAtt;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getLogin() {
        return Login;
    }

    public void setLogin(String Login) {
        this.Login = Login;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public UserRole getUserRole() {
        return UserRole;
    }

    public void setUserRole(UserRole UserRole) {
        this.UserRole = UserRole;
    }

    public UserPref getUserPref() {
        return UserPref;
    }

    public void setUserPref(UserPref userPref) {
        UserPref = userPref;
    }
}

