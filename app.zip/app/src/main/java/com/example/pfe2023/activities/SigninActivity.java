package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.BASE_URL;
import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.Utils.showSnackbar;

import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.Utils.showSnackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.pfe2023.R;
import com.example.pfe2023.models.ApiResponse;
import com.example.pfe2023.models.Location;
import com.example.pfe2023.models.LoginResponse;
import com.example.pfe2023.models.User;
import com.example.pfe2023.models.UserLogin;
import com.example.pfe2023.models.UserPref;
import com.example.pfe2023.models.UserRole;
import com.example.pfe2023.retrofit.RetrofitClient;
import com.example.pfe2023.retrofit.RetrofitInterface;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SigninActivity extends AppCompatActivity {

    private AppCompatEditText etLogin;
    private AppCompatEditText etPassword;
    private AppCompatButton btnLogin;

    private AppCompatTextView signup ;
    private ProgressBar pb;

    private static boolean _Running = false;


    public SigninActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        bindViews();
        init();
    }

    private void bindViews() {
        etLogin = (AppCompatEditText) findViewById(R.id.Username);
        etPassword = (AppCompatEditText) findViewById(R.id.Loginpassword);
        signup = findViewById(R.id.newacc2);
        btnLogin = (AppCompatButton) findViewById(R.id.Sign_in);
        pb = (ProgressBar) findViewById(R.id.pb_login);
    }

    private void showSnackbarWithAction(View view, String message, String actionText, View.OnClickListener actionClickListener) {
        Snackbar snackbar = Snackbar.make(view, message, Snackbar.LENGTH_LONG);
        snackbar.setAction(actionText, actionClickListener);
        snackbar.show();
    }

    private void init() {

//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//                    505);
//        } else {
//            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
//        }

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(i);
                finish();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (TextUtils.isEmpty(etLogin.getText().toString())) {
                        etLogin.setError("Username is missing");
                    } else if (TextUtils.isEmpty(etPassword.getText().toString())) {
                        etPassword.setError("password is missing");
                    } else
                        Verify();


                } catch (Exception e) {
                    showSnackbar(findViewById(android.R.id.content), e.toString());
                }
            }
        });
    }

    /*************************************(  POST  )****************************************/
    public void Verify() {
        String URL = "api/User/UserLogin";
        final String content_type = "application/json";
        UserLogin _UserLogin = new  UserLogin();
        _UserLogin.setUsername(etLogin.getText().toString());
        _UserLogin.setPassword(etPassword.getText().toString());
        pb.setVisibility(View.VISIBLE);

        //showSnackbar(findViewById(android.R.id.content), BASE_URL + URL);

        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<LoginResponse> userCall = service.userLoginQuery(URL, content_type, _UserLogin);

        btnLogin.setEnabled(false);

        userCall.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                btnLogin.setEnabled(true);
                pb.setVisibility(View.GONE);
                if (response.raw().code() == 200) {
                    LoginResponse _Data = response.body();
                    if (_Data.getSuccess()){
                        CUR_USER = _Data.getUser();
                        Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                        startActivity(i);
                        finish();

                    } else {
                        showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());
                    }
                    showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());

                } else {
                    showSnackbar(findViewById(android.R.id.content), response.message());
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), "error_message_server_down");
                btnLogin.setEnabled(true);
                pb.setVisibility(View.GONE);
            }
        });

    }

}