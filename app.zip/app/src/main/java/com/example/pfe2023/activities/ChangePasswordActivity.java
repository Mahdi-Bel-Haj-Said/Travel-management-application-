package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.Utils.showSnackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.example.pfe2023.R;
import com.example.pfe2023.models.ApiResponse;
import com.example.pfe2023.models.User;
import com.example.pfe2023.models.UserRole;
import com.example.pfe2023.retrofit.RetrofitClient;
import com.example.pfe2023.retrofit.RetrofitInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePasswordActivity extends AppCompatActivity {

    AppCompatEditText oldpassword , newpassword ,newpassword2 ;
    AppCompatButton btnsave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        oldpassword = (AppCompatEditText) findViewById(R.id.inputoldpassword);
        newpassword = (AppCompatEditText) findViewById(R.id.inputnewpassword);
        newpassword2 = (AppCompatEditText) findViewById(R.id.inputnewpassword2);
        btnsave = (AppCompatButton) findViewById(R.id.buttonsave);




    }
    private void init() {

        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (TextUtils.isEmpty(oldpassword.getText().toString())) {
                        oldpassword.setError("old password is missing");
                    } else if (TextUtils.isEmpty(newpassword.getText().toString())) {
                        newpassword.setError("new password is missing");
                    } else if (TextUtils.isEmpty(newpassword2.getText().toString())) {
                        newpassword2.setError("new password is missing");
                    } else if (!newpassword.getText().toString().equals(newpassword2.getText().toString())) {
                        newpassword2.setError("new password doesn't match");
                    } else {
                        updateUser();
                    }

                } catch (Exception e) {
                    showSnackbar(findViewById(android.R.id.content), e.toString());
                }
            }
        });
    }

    public void updateUser() {

        String URL = "api/User/UpdateUser";
        final String content_type = "application/json";
        UserRole _UserRole = new UserRole();
        _UserRole.setRoleId(CUR_USER.getUserRole().getRoleId());
        User _User = new User();
        _User.setLogin(CUR_USER.getLogin());
        _User.setPassword(newpassword.getText().toString());
        _User.setFirstName(CUR_USER.getFirstName());
        _User.setLastName(CUR_USER.getLastName());
        _User.setEmail(CUR_USER.getEmail());
        _User.setPhone(CUR_USER.getPhone());
        _User.setUserRole(_UserRole);

        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<ApiResponse> userCall = service.addNewUserQuery(URL, content_type, _User);

        btnsave.setEnabled(false);

        userCall.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                btnsave.setEnabled(true);
                if (response.raw().code() == 200) {
                    ApiResponse _Data = response.body();
                    if (_Data.getSuccess()){
                        Intent i = new Intent(getApplicationContext(), SigninActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());
                    }
                } else {
                    showSnackbar(findViewById(android.R.id.content), response.message());
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), "error_message_server_down");
                btnsave.setEnabled(true);
            }
        });

    }
}