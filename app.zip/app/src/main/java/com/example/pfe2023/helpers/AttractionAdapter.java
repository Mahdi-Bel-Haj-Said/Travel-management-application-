package com.example.pfe2023.helpers;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pfe2023.R;
import com.example.pfe2023.models.Attraction;
import com.example.pfe2023.models.User;
import com.example.pfe2023.models.UserAtt;

import java.util.ArrayList;

public class AttractionAdapter extends RecyclerView.Adapter<AttractionAdapter.MultiViewHolder> {



    private Context context ;
    private ArrayList<UserAtt> attractions;

    private ArrayList<UserAtt> selectedattractions;



    public AttractionAdapter(Context context, ArrayList<UserAtt> attractions) {
        this.context = context;
        this.attractions = attractions;
    }

    public  void setAttractions (ArrayList<UserAtt> attractions){
        this.attractions = new ArrayList<>();
        this.attractions = attractions ;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MultiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.attraction,
                parent , false);
        return new MultiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MultiViewHolder holder, int position) {
            holder.bind(attractions.get(position));
    }

    @Override
    public int getItemCount() {
        return attractions.size();
    }

    class MultiViewHolder extends RecyclerView.ViewHolder{
        private AppCompatTextView textView ;
        private AppCompatImageView imageView ;
        private CardView card ;

        public  MultiViewHolder(@NonNull View itemView){
            super(itemView);
            textView = itemView.findViewById(R.id.AttractionText);
            imageView = itemView.findViewById(R.id.checkimg);
            card = itemView.findViewById(R.id.attractionCardItem);


        }


        void bind (final  UserAtt attraction){
            imageView.setVisibility(attraction.isChecked() ? View.VISIBLE : View.GONE ) ;
            textView.setText(attraction.getAttName());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    attraction.setChecked(!attraction.isChecked());
                    imageView.setVisibility(attraction.isChecked()? View.VISIBLE : View.GONE);
                    card.setCardBackgroundColor(attraction.isChecked()? Color.parseColor("#FF0D6E"): Color.WHITE);
                }
            });

        }

    }


    public ArrayList<UserAtt> getAll(){
        return attractions;
    }


    public ArrayList<UserAtt> getSelected() {
        for (int i = 0 ; i< attractions.size(); i++ )
        {
            if (attractions.get(i).isChecked() )
            {
                selectedattractions.add(attractions.get(i));
            }
        }
        return selectedattractions;
    }
}
