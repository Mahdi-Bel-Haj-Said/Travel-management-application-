package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.pfe2023.R;
import com.example.pfe2023.helpers.AttractionAdapter;
import com.example.pfe2023.helpers.MyprefAdapter;
import com.example.pfe2023.models.Attraction;
import com.example.pfe2023.models.UserAtt;

import java.util.ArrayList;

public class MyPreferencesActivity extends AppCompatActivity {
    RecyclerView recyclerView ;
    private MyprefAdapter adapter ;
    AppCompatButton btn;

   AppCompatTextView budget;
   AppCompatTextView wait;



    private ArrayList<UserAtt> attractions = new ArrayList<UserAtt>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_preferences);
        budget = findViewById(R.id.Profilebudget);
        wait = findViewById(R.id.profilewait);
        recyclerView = findViewById(R.id.myprefRecycler);
        btn = findViewById(R.id.button);
        budget.setText("Budget :"+CUR_USER.getUserPref().getBudget().toString()+" dt");
        wait.setText("Average Wait :"+CUR_USER.getUserPref().getWait().toString()+ " mins");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));

        adapter = new MyprefAdapter(this , attractions );
        recyclerView.setAdapter(adapter);
        CreateListOfData();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Pref1Activity.class);
                startActivity(i);
                finish();
            }

        });



    }
    private void CreateListOfData() {

        attractions = new ArrayList<>();
        attractions = CUR_USER.getUserAtt();
        adapter.setAttractions(attractions);
    }


}