package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.ALL_DESTINATIONS;
import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.ConstantConfig.MY_DESTINATIONS;
import static com.example.pfe2023.helpers.ConstantConfig.SELECTED_DEST;
import static com.example.pfe2023.helpers.Utils.showSnackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import com.example.pfe2023.R;
import com.example.pfe2023.helpers.DestAdapter;
import com.example.pfe2023.helpers.MySpinnerAdapter;
import com.example.pfe2023.models.Destination;
import com.example.pfe2023.models.DestinationResponse;
import com.example.pfe2023.models.UserAtt;
import com.example.pfe2023.retrofit.RetrofitClient;
import com.example.pfe2023.retrofit.RetrofitInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GeneratedDestinationsActivity extends AppCompatActivity {

    private static final double EARTH_RADIUS = 6371.0; // Radius of the Earth in kilometers

    RecyclerView recyclerView;
    private MySpinnerAdapter spAdapter;
    private DestAdapter destAdapter;
    AppCompatImageButton btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated_destinations);


        MY_DESTINATIONS = GenerateDest(ALL_DESTINATIONS, CUR_USER.getUserPref().getWait(), CUR_USER.getUserPref().getBudget(), CUR_USER.getUserAtt()) ;

        //ToDo Madi From DB

//        ALL_DESTINATIONS.add(new Destination(1, "Al hnaya", 1));
//        ALL_DESTINATIONS.add(new Destination(2, "Douz", 2));
//        ALL_DESTINATIONS.add(new Destination(3, "Hammam laghzez", 3));
//        ALL_DESTINATIONS.add(new Destination(4, "Painball nahli", 4));
//        ALL_DESTINATIONS.add(new Destination(5, "Sidi Bousaid", 5));

        RecyclerView recyclerView = findViewById(R.id.SelectedDest);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        destAdapter = new DestAdapter(MY_DESTINATIONS);
        recyclerView.setAdapter(destAdapter);

        findViewById(R.id.add).setOnClickListener(view -> {

            Dialog dialog = new Dialog(GeneratedDestinationsActivity.this);
            dialog.setContentView(R.layout.add_dest);
            AppCompatButton btnAdd = dialog.findViewById(R.id.buttonAdd);
            AppCompatSpinner spDest = dialog.findViewById(R.id.destSpinner);

            spAdapter = new MySpinnerAdapter(getApplicationContext(), ALL_DESTINATIONS);
            spDest.setAdapter(spAdapter);

            spDest.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> spinner, View container, int position, long id) {
                    SELECTED_DEST = ALL_DESTINATIONS.get(position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });

            btnAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (!MY_DESTINATIONS.contains(SELECTED_DEST)) {
                            MY_DESTINATIONS.add(SELECTED_DEST);
                        } else {
                            showSnackbar(findViewById(android.R.id.content), "Destination Exist");
                        }
                        destAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        showSnackbar(findViewById(android.R.id.content), e.toString());
                    }
                }
            });

            dialog.show();

        });


//        recyclerView = findViewById(R.id.SelectedDest);
//        btn = findViewById(R.id.add);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));
//        adapter = new DestAdapter(this , destinations );
//        recyclerView.setAdapter(adapter);
//
//        adapter.setOnItemClickedListener(new DestAdapter.OnItemClickListener() {
//            @Override
//            public void onItemClick(int position) {
//                destinations.remove(position);
//                adapter.notifyItemRemoved(position);
//            }
//        });
//
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Dialog dialog = new Dialog(GeneratedDestinationsActivity.this);
//                dialog.setContentView(R.layout.add_dest);
//                AppCompatSpinner spinner = dialog.findViewById(R.id.destSpinner);
//                AppCompatButton add = dialog.findViewById(R.id.buttonAdd);
//                btn.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        int i = destinations.size();
//                        String name = spinner.getSelectedItem().toString();
//                        destinations.add(new Destination(name,i+1));
//                        adapter.notifyItemInserted(destinations.size()-1);
//                        dialog.dismiss();
//
//
//                    }
//                });
//                dialog.show();
//            }
//        });


    }

        public static double getDistance(double longitude1, double latitude1, double longitude2, double latitude2) {
            double lon1Radians = Math.toRadians(longitude1);
            double lat1Radians = Math.toRadians(latitude1);
            double lon2Radians = Math.toRadians(longitude2);
            double lat2Radians = Math.toRadians(latitude2);

            double dlon = lon2Radians - lon1Radians;
            double dlat = lat2Radians - lat1Radians;

            double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1Radians) * Math.cos(lat2Radians)
                    * Math.pow(Math.sin(dlon / 2), 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

            double distance = EARTH_RADIUS * c;
            return distance;
        }
    public ArrayList<Destination>GenerateDest(ArrayList<Destination> destinations, double wait, double budget, ArrayList<UserAtt> attractions) {
        ArrayList<Destination> resultDest = new ArrayList<Destination>();

        for (Destination destination : destinations) {
            boolean isValid = false;

            for (UserAtt attraction : attractions) {
                if (destination.getAttractions().contains(attraction)) {
                    isValid = true;
                    break;
                }
            }

            if (!isValid || destination.getBudget() > budget || destination.getWait() > wait) {
                continue;
            }

            resultDest.add(destination);
        }

        return resultDest;
    }
//    public static List<Destination> calculateOptimalCircuit(List<Destination> places) {
//        // Add the starting point (0 latitude, 0 longitude) as the first place in the circuit
//        List<Destination> circuit = new ArrayList<>();
//        circuit.add(new Destination("Starting Point", 0.0, 0.0));
//
//        // Copy the remaining places to a new list
//        List<Destination> remainingPlaces = new ArrayList<>(places);
//
//        // Loop until all places have been visited
//        while (!remainingPlaces.isEmpty()) {
//            double minDistance = Double.MAX_VALUE;
//            Destination nearestPlace = null;
//
//            // Find the nearest unvisited place from the last visited place in the circuit
//            Destination lastPlace = circuit.get(circuit.size() - 1);
//            for (Destination place : remainingPlaces) {
//                double distance = getDistance(lastPlace.getLongitude(), lastPlace.getLatitude(),
//                        place.getLongitude(), place.getLatitude());
//                if (distance < minDistance) {
//                    minDistance = distance;
//                    nearestPlace = place;
//                }
//            }
//
//            // Add the nearest place to the circuit and remove it from the remaining places
//            circuit.add(nearestPlace);
//            remainingPlaces.remove(nearestPlace);
//        }
//
//        return circuit;
//    }


}