package com.example.pfe2023.models;

import java.io.Serializable;

public class Myprefattraction implements Serializable {

    private boolean isChecked = false;
    private  String attraction ;

    public Myprefattraction(String attraction) {
        this.attraction = attraction;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public String getAttraction() {
        return attraction;
    }

    public void setAttraction(String attraction) {
        this.attraction = attraction;
    }
}
