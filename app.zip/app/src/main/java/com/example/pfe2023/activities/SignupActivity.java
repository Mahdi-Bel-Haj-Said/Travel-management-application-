package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.Utils.showSnackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ProgressBar;

import com.example.pfe2023.R;
import com.example.pfe2023.models.ApiResponse;
import com.example.pfe2023.models.User;
import com.example.pfe2023.models.UserRole;
import com.example.pfe2023.retrofit.RetrofitClient;
import com.example.pfe2023.retrofit.RetrofitInterface;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {

    private AppCompatEditText etLogin;
    private AppCompatEditText etPassword;
    private AppCompatEditText etConfPass;
    private AppCompatEditText etFName;
    private AppCompatEditText etLName;
    private AppCompatEditText etEmail;
    private AppCompatEditText etPhone;

    private AppCompatTextView oldacc ;

    //AppCompatEditText etPhone = new AppCompatEditText(this);
    //int maxLength = 8;
    //etPhone.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maxLength)});

    private AppCompatButton btnOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        bindViews();
        init();


        oldacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SigninActivity.class);
                startActivity(i);
                finish();
            }
        });

    }

    /***************************************************************************************************/

    private void bindViews() {

        etLogin = (AppCompatEditText) findViewById(R.id.passwordEditText3);
        etPassword = (AppCompatEditText) findViewById(R.id.passwordEditText4);
        etConfPass = (AppCompatEditText) findViewById(R.id.passwordEditText5);
        etFName = (AppCompatEditText) findViewById(R.id.firstName);
        etLName = (AppCompatEditText) findViewById(R.id.fullname);
        etEmail = (AppCompatEditText) findViewById(R.id.passwordEditText2);
        etPhone = (AppCompatEditText) findViewById(R.id.passwordEditText);
        oldacc = findViewById(R.id.oldacc);
        btnOK = (AppCompatButton) findViewById(R.id.button);
    }

    //This method is for init Views.
    private void init() {

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (TextUtils.isEmpty(etFName.getText().toString())) {
                        etFName.setError("FirstName is a must");
                    } else if (TextUtils.isEmpty(etLName.getText().toString())) {
                        etLName.setError("Name is a must");
                    } else if (TextUtils.isEmpty(etPhone.getText().toString())) {
                        etPhone.setError("Number is a must for safety");
                    } else if (TextUtils.isEmpty(etEmail.getText().toString())) {
                        etEmail.setError("Email is a must");
                    } else if (!etEmail.getText().toString().contains("@")) {
                        etEmail.setError("Wrong Email Address !");
                    } else if (TextUtils.isEmpty(etLogin.getText().toString())) {
                        etLogin.setError("Username is a must");
                    } else if (TextUtils.isEmpty(etPassword.getText().toString())) {
                        etPassword.setError("Password is a must");
                    } else if (TextUtils.isEmpty(etConfPass.getText().toString())) {
                        etConfPass.setError("Password is a must");
                    } else if (!etPassword.getText().toString().equals(etConfPass.getText().toString())) {
                        etConfPass.setError("doesn't match password");
                    } else if (etPhone.getText().toString().length() > 8 || etPhone.getText().toString().length() < 8) {
                        etPhone.setError("8 numbers only !");
                    }  else {
                        addNewUser();
                    }

                } catch (Exception e) {
                    showSnackbar(findViewById(android.R.id.content), e.toString());
                }
            }
        });
    }

    /*************************************(  POST  )****************************************/

    public void addNewUser() {

        String URL = "api/User/AddUser";
        final String content_type = "application/json";
        UserRole _UserRole = new UserRole();
        _UserRole.setRoleId(2);

        User _User = new User();
        _User.setLogin(etLogin.getText().toString());
        _User.setPassword(etPassword.getText().toString());
        _User.setFirstName(etFName.getText().toString());
        _User.setLastName(etLName.getText().toString());
        _User.setEmail(etEmail.getText().toString());
        _User.setPhone(etPhone.getText().toString());
        _User.setUserRole(_UserRole);

        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<ApiResponse> userCall = service.addNewUserQuery(URL, content_type, _User);

        btnOK.setEnabled(false);

        userCall.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                btnOK.setEnabled(true);
                if (response.raw().code() == 200) {
                    ApiResponse _Data = response.body();
                    if (_Data.getSuccess()){
                        Intent i = new Intent(getApplicationContext(), SigninActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());
                    }
                } else {
                    showSnackbar(findViewById(android.R.id.content), response.message());
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), "error_message_server_down");
                btnOK.setEnabled(true);
            }
        });

    }
}