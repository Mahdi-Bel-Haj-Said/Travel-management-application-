package com.example.pfe2023.helpers;


import com.example.pfe2023.models.Destination;
import com.example.pfe2023.models.User;
import com.example.pfe2023.models.UserAtt;
import com.example.pfe2023.models.UserPref;

import java.util.ArrayList;

public class ConstantConfig {

    /********************** *****************( Final )************************  *******************/
    //FINAL BASE URL
    public static final String FINAL_BASE_URL = "";

    /***************************************(Non Final )*******************************************/
    //BASE URL
    public static String BASE_URL = "http://10.10.21.78/API/";
    public static User CUR_USER = null;
    public static Destination SELECTED_DEST = null;
    public static UserPref USER_PREF = null;

    public static ArrayList<UserAtt> ALL_ATTRACTIONS = new ArrayList<>();
    public static ArrayList<Destination> MY_DESTINATIONS = new ArrayList<>();
    public static ArrayList<Destination> ALL_DESTINATIONS = new ArrayList<>();

    public static ArrayList<UserAtt> SELECTED_ATTRACTIONS = new ArrayList<>();

}
