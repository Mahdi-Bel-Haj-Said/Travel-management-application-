package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.ALL_ATTRACTIONS;
import static com.example.pfe2023.helpers.ConstantConfig.ALL_DESTINATIONS;
import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;
import static com.example.pfe2023.helpers.Utils.showSnackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.pfe2023.R;
import com.example.pfe2023.models.ApiResponse;
import com.example.pfe2023.models.AttractionResponse;
import com.example.pfe2023.models.DestinationResponse;
import com.example.pfe2023.models.Location;
import com.example.pfe2023.retrofit.RetrofitClient;
import com.example.pfe2023.retrofit.RetrofitInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {


    LinearLayout dest, pref, changePref, profile;
    AppCompatImageButton logout;
    AppCompatButton start;
    AppCompatTextView name;

    private static Double _Latitude;
    private static Double _Longitude;

    private LocationManager locationManager;

    private LocationListener locationListener;

    private long lastUpdateTime = 0;  // Variable pour stocker le temps de la dernière mise à jour de localisation
    private android.location.Location previousLocation = null;  // Variable pour stocker la dernière position enregistrée

    private static Boolean firstStart = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        bindViews();
        getAllPlaces();
        GetAllAttractions();
        init();
    }

    private void bindViews() {
        dest = findViewById(R.id.destinationshome);
        pref = findViewById(R.id.Preferenceshome);
        changePref = findViewById(R.id.changeprefhome);
        profile = findViewById(R.id.Profilehome);
        logout = findViewById(R.id.Logout);
        start = findViewById(R.id.Start);
        name = findViewById(R.id.hello);
    }

    private void init() {

        lastUpdateTime = System.currentTimeMillis();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull android.location.Location location) {
                _Latitude = location.getLatitude();
                _Longitude = location.getLongitude();

                showSnackbar(findViewById(android.R.id.content), "_Latitude : "+_Latitude+" _Longitude : "+_Longitude);

                if (previousLocation == null) {
                    previousLocation = location;
                }

                // Vérifier si le temps écoulé depuis la dernière mise à jour est supérieur à 2 minutes
                long currentTime = System.currentTimeMillis();
                long timeDifference = currentTime - lastUpdateTime;
                boolean isTimeElapsed = timeDifference >= (5 * 1 * 1000); // 2 minutes en millisecondes

                // Vérifier si la distance parcourue depuis la dernière mise à jour est supérieure à 100 mètres
                boolean isDistanceCovered = false;
                if (previousLocation != null) {
                    float distance = location.distanceTo(previousLocation);
                    isDistanceCovered = distance >= 10; // 10 mètres
                }
                    // Vérifier si les conditions de temps et de distance sont satisfaites
                    if (firstStart || isDistanceCovered) {
                        // Mettre à jour la dernière heure de mise à jour et la dernière position
                        lastUpdateTime = currentTime;
                        previousLocation = location;
                        firstStart = false;
                        Location _Location = new Location();
                        _Location.setLongitude(_Longitude.toString());
                        _Location.setLatitude(_Latitude.toString());
                        _Location.setUserId(CUR_USER.getUserId());

                        addLocations(_Location);
                }
            }


            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    505);
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }

        dest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Destinationslist.class);
                startActivity(i);
            }
        });
        pref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MyPreferencesActivity.class);
                startActivity(i);
            }
        });
        changePref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Pref1Activity.class);
                startActivity(i);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                startActivity(i);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SigninActivity.class);
                startActivity(i);
                finish();
            }
        });
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), GeneratedDestinationsActivity.class);
                startActivity(i);
            }
        });


        StringBuilder str = new StringBuilder();

        name.setText("Hello"+CUR_USER.getFirstName());

    }

    public void addLocations(Location location) {
        showSnackbar(findViewById(android.R.id.content), "addLocations");
        String URL = "api/User/AddLocation";
        final String content_type = "application/json";
        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<ApiResponse> userCall = service.addNewLocationsQuery(URL, content_type, location);

        userCall.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                showSnackbar(findViewById(android.R.id.content), "" + response.raw().code());
                if (response.raw().code() == 200) {
                    ApiResponse _Data = response.body();
                    showSnackbar(findViewById(android.R.id.content), _Data.getMessage());
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), t.getMessage());
            }
        });
    }



    /*************************************(  GET  )****************************************/

    public void getAllPlaces() {
        String URL = "api/Place/GetPlaces";

        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<DestinationResponse> PlaceCall = service.getPlacesQuery(URL);

        PlaceCall.enqueue(new Callback<DestinationResponse>() {
            @Override
            public void onResponse(Call<DestinationResponse> call, Response<DestinationResponse> response) {


                if (response.raw().code() == 200) {
                    DestinationResponse _Data = response.body();
                    if (_Data.getSuccess()){
                        ALL_DESTINATIONS = _Data.getPlaces();
//                        Intent i = new Intent(getApplicationContext(), HomeActivity.class);
//                        startActivity(i);
//                        finish();

                    } else {
                        showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());
                    }
                    showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());

                } else {
                    showSnackbar(findViewById(android.R.id.content), response.message());
                }
            }

            @Override
            public void onFailure(Call<DestinationResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), "error_message_server_down");
            }
        });

    }


    public void GetAllAttractions() {
        String URL = "api/Place/GetAllAttractions";

        RetrofitInterface service = RetrofitClient.getClientApi().create(RetrofitInterface.class);
        Call<AttractionResponse> AttractionCall = service.getAttractionsQuery(URL);

        AttractionCall.enqueue(new Callback<AttractionResponse>() {
            @Override
            public void onResponse(Call<AttractionResponse> call, Response<AttractionResponse> response) {


                if (response.raw().code() == 200) {
                    AttractionResponse _Data = response.body();
                    if (_Data.getSuccess()){
                        ALL_ATTRACTIONS = _Data.getAttractions();
//                        Intent i = new Intent(getApplicationContext(), HomeActivity.class);
//                        startActivity(i);
//                        finish();

                    } else {
                        showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());
                    }
                    showSnackbar(findViewById(android.R.id.content), _Data.getMessage().toString());

                } else {
                    showSnackbar(findViewById(android.R.id.content), response.message());
                }
            }

            @Override
            public void onFailure(Call<AttractionResponse> call, Throwable t) {
                showSnackbar(findViewById(android.R.id.content), "error_message_server_down");
            }
        });

    }
}