package com.example.pfe2023.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Attraction implements Serializable {


    private boolean isChecked = false;

    @SerializedName("attractionId")
    @Expose
    private  int id ;

    @SerializedName("name")
    @Expose
    private  String attraction ;

    public Attraction(String attraction) {
        this.attraction = attraction;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public String getAttraction() {
        return attraction;
    }

    public void setAttraction(String attraction) {
        this.attraction = attraction;
    }
}
