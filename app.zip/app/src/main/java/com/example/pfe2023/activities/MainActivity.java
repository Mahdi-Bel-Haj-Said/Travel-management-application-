package com.example.pfe2023.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.pfe2023.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Intent i = new Intent(getApplicationContext(), SignupActivity.class);
        //Intent i = new Intent(getApplicationContext(), MyPreferencesActivity.class);
        //Intent i = new Intent(getApplicationContext(), SigninActivity.class);
        Intent i = new Intent(getApplicationContext(), SigninActivity.class);
        startActivity(i);
        finish();
    }
}