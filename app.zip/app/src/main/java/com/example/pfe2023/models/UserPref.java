package com.example.pfe2023.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class UserPref {

        @SerializedName("id")
        @Expose
        private Integer userId;

        @SerializedName("budget")
        @Expose
        private Double budget;

        @SerializedName("waittime")
        @Expose
        private Integer wait;

        @SerializedName("attractions")
        @Expose
        private ArrayList<Attraction> attractions;


        public Integer getUserId() {
            return userId;
        }

        public void setUserId(Integer userId) {
            this.userId = userId;
        }

        public Double getBudget() {
            return budget;
        }

        public void setBudget(Double budget) {
            this.budget = budget;
        }

        public Integer getWait() {
            return wait;
        }

        public void setWait(Integer wait) {
            this.wait = wait;
        }

        public ArrayList<Attraction> getAttractions() {
            return attractions;
        }

        public void setAttractions(ArrayList<Attraction> attractions) {
            this.attractions = attractions;
        }
}
