package com.example.pfe2023.activities;

import static com.example.pfe2023.helpers.ConstantConfig.CUR_USER;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.widget.ImageViewCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.pfe2023.R;

public class ProfileActivity extends AppCompatActivity {
    AppCompatImageButton logout;
    AppCompatImageButton back ;

    AppCompatImageView pwd , show ;

    AppCompatTextView name , Email , phone , username ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        logout = findViewById(R.id.Logout);
        back = findViewById(R.id.Back);
        pwd = findViewById(R.id.changepwd);
        name = findViewById(R.id.nameprofile2);
        Email = findViewById(R.id.mailprofile2);
        phone = findViewById(R.id.phoneprofile2);
        username = findViewById(R.id.ProfileName);
        show = findViewById(R.id.pwdprofile);



        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SigninActivity.class);
                startActivity(i);
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(i);
                finish();
            }
        });

        pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ChangePasswordActivity.class);
                startActivity(i);
            }
        });

        name.setText(CUR_USER.getFirstName()+""+CUR_USER.getLastName());
        Email.setText(CUR_USER.getEmail());
        phone.setText("+216"+CUR_USER.getPhone());
        username.setText(CUR_USER.getLogin());

//        StringBuilder strname = new StringBuilder();
//        strname.append(CUR_USER.getFirstName());
//        strname.append("  ");
//        strname.append(CUR_USER.getLastName());
//        name.setText(strname.toString());

//
//        StringBuilder strmail = new StringBuilder();
//        strmail.append(CUR_USER.getEmail());
//        Email.setText(strmail.toString());
//
//
//        StringBuilder strphone = new StringBuilder();
//        strphone.append(CUR_USER.getPhone());
//        phone.setText(strphone.toString());
//


//
//        show.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                password.setInputType(text);
//            }
//        });





    }
}