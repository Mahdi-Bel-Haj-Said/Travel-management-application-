package com.example.pfe2023.retrofit;

import android.util.Log;

import com.example.pfe2023.models.ApiResponse;
import com.example.pfe2023.models.AttractionResponse;
import com.example.pfe2023.models.Destination;
import com.example.pfe2023.models.DestinationResponse;
import com.example.pfe2023.models.Location;
import com.example.pfe2023.models.LocationData;
import com.example.pfe2023.models.LoginResponse;
import com.example.pfe2023.models.User;
import com.example.pfe2023.models.UserLogin;
import com.example.pfe2023.models.UserPref;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface RetrofitInterface {

    /***
     ** GET *********************************************************************************************
     **/

    //Get All Data service call
    @GET
    Call<LocationData> getAllLocationsQuery(@Url String URL);

    @GET
    Call<DestinationResponse> getPlacesQuery(@Url String URL);

    @GET
    Call<AttractionResponse> getAttractionsQuery(@Url String URL);
    /***
     ** POST ********************************************************************************************
     **/

    @POST
    Call<ApiResponse> addNewLocationsQuery(@Url String URL,
                                           @Header("Content-Type") String content_type,
                                           @Body Location location);
    @POST
    Call<ApiResponse> addNewUserQuery(@Url String URL,
                                      @Header("Content-Type") String content_type,
                                      @Body User user);
    @POST
    Call<LoginResponse> userLoginQuery(@Url String URL,
                                       @Header("Content-Type") String content_type,
                                       @Body UserLogin userLogin);

    @POST
    Call<ApiResponse> updateUserQuery(@Url String URL,
                                      @Header("Content-Type") String content_type,
                                      @Body User user);

    @POST
    Call<LoginResponse> addUserPrefQuery(@Url String URL,
                               @Header("Content-Type") String content_type,
                               @Body UserPref userpref);



}
